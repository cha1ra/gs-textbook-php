<?php
$name = "どんぶラッコ";
$birthMonth = 1;
$isStudent = true;

// 変数の情報を表示
var_dump($name);
echo "<br>";
var_dump($birthMonth);
echo "<br>";
var_dump($isStudent);
echo "<br>";
?>