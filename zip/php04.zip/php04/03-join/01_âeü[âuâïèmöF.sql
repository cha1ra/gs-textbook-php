-- ============================================
-- テーブルの確認
-- ============================================

USE join_sample;

-- 各テーブルの中身を確認
SELECT * FROM students;
SELECT * FROM instructors;
SELECT * FROM courses;
SELECT * FROM enrollments;
