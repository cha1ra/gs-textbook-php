<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!-- 年を表示 -->
    <h1>今年はXXXX年です</h1>

    <!-- HTMLをPHPから出力 -->
    
</body>
</html>