<?php
// ini_set('display_errors', 'On');    // エラーを表示させる
// error_reporting(E_ALL);              // 全てのレベルのエラーを表示

// 存在しない関数を呼び出す（Fatal Error）- いきなりエラーで何も表示されない
undefined_function();

?>
